# heim-common

This crate shares common functionality across the `heim` project.

Do **NOT** use it directly.
