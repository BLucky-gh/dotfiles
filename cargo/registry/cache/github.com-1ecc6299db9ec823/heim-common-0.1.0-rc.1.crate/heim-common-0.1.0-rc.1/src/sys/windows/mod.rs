//! Windows-specific routines used across `heim` crates.

mod handle;
mod time;

pub use self::handle::Handle;
