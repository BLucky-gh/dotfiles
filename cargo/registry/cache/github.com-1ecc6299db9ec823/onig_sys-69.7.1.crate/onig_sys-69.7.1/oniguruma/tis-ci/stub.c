void srand(unsigned int seed) {
  return;
}
