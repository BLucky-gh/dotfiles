# heim-memory

> Cross-platform information about system memory.

`heim-memory` a part of [heim project](https://github.com/heim-rs),
and **SHOULD NOT** be used directly,
but via [heim](https://crates.io/crates/heim) crate.
