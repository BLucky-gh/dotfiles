//! macOS-specific extensions.

mod stats;

pub use self::stats::*;
