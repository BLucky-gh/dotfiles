# Demo

This directory contains the demo material for [gpg-tui](https://github.com/orhun/gpg-tui). All GIFs are recorded using [rec.sh](rec.sh) script.
