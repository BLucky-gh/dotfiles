# heim-runtime

[![Latest Version](https://img.shields.io/crates/v/heim-runtime.svg)](https://crates.io/crates/heim-runtime)
[![Latest Version](https://docs.rs/heim-runtime/badge.svg)](https://docs.rs/heim-runtime)
[![dependency status](https://deps.rs/crate/heim-runtime/0.0.6/status.svg)](https://deps.rs/crate/heim-runtime/0.0.6)
[![CI status](https://github.com/heim-rs/heim/workflows/Continuous%20integration/badge.svg)](https://github.com/heim-rs/heim/actions?workflow=Continuous+integration)
![Apache 2.0 OR MIT licensed](https://img.shields.io/badge/license-Apache2.0%2FMIT-blue.svg)
[![Gitter](https://badges.gitter.im/heim-rs/heim.svg)](https://gitter.im/heim-rs/heim)

> Cross-platform information about system running.

`heim-runtime` a part of [heim project](https://github.com/heim-rs),
and preferably should not be used directly,
but via [heim](https://crates.io/crates/heim) crate.
