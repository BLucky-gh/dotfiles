//
// Sysinfo
//
// Copyright (c) 2021 Guillaume Gomez
//

pub use crate::sys::inner::component::*;
