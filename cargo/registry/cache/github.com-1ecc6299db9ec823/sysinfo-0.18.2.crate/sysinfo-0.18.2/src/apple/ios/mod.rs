//
// Sysinfo
//
// Copyright (c) 2021 Guillaume Gomez
//

pub mod component;
pub mod ffi {}
pub use crate::sys::app_store::process;
