#### Software version

bugreport 0.4.0 (4687617)

#### Operating system

Linux 5.11.14-arch1-1

#### Command-line

```bash
/home/shark/.cargo-target/debug/examples/readme '"test value" on command line' two three 
```

#### Environment variables

```bash
SHELL=/usr/bin/zsh
EDITOR=vim
```

#### Python version

```
> python -V 
Python 3.9.3
```

#### Compile time information

- Profile: debug
- Target triple: x86_64-unknown-linux-gnu
- Family: unix
- OS: linux
- Architecture: x86_64
- Pointer width: 64
- Endian: little
- CPU features: fxsr,sse,sse2
- Host: x86_64-unknown-linux-gnu


