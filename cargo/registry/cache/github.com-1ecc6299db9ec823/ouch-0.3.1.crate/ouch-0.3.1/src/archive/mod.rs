//! Archive compression algorithms

pub mod tar;
pub mod zip;
