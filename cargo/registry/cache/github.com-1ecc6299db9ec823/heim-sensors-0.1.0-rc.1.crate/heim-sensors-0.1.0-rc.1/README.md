# heim-sensors

[![Latest Version](https://img.shields.io/crates/v/heim-sensors.svg)](https://crates.io/crates/heim-sensors)
[![Latest Version](https://docs.rs/heim-sensors/badge.svg)](https://docs.rs/heim-sensors)
[![dependency status](https://deps.rs/crate/heim-sensors/0.0.5/status.svg)](https://deps.rs/crate/heim-sensors/0.0.5)
[![CI status](https://github.com/heim-rs/heim/workflows/Continuous%20integration/badge.svg)](https://github.com/heim-rs/heim/actions?workflow=Continuous+integration)
![Apache 2.0 OR MIT licensed](https://img.shields.io/badge/license-Apache2.0%2FMIT-blue.svg)
[![Gitter](https://badges.gitter.im/heim-rs/heim.svg)](https://gitter.im/heim-rs/heim)

> Cross-platform information about system sensors.

`heim-sensors` a part of [heim project](https://github.com/heim-rs),
and preferably should not be used directly,
but via [heim](https://crates.io/crates/heim) crate.
