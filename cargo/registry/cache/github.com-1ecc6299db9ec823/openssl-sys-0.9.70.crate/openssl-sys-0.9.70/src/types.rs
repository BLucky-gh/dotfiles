#[cfg(ossl300)]
pub enum OSSL_LIB_CTX {}
