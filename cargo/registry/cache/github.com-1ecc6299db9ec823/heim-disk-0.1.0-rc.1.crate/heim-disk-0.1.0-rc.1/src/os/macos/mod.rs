//! macOS-specific extensions.

mod partitions;

pub use self::partitions::*;
