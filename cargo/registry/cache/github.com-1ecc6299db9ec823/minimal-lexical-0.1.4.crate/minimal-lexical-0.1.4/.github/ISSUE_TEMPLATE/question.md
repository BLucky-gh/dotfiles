---
name: Question
about: Have a question how to use minimal-lexical?
title: "[QUESTION]"
labels: question
assignees: Alexhuszagh

---

## Question
A clear and concise description of what the question is. Ex. how do I use minimal-lexical without a system allocator?
